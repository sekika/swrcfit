==================== SWRC Fit ====================

SWRC Fit is a scientific tool for hydrologist. It fits
several soil hydraulic models to measured soil water
retention data by nonlinear fitting. It is written in
numerical calculation language GNU Octave. Web interface
is also available.

Website: http://purl.org/net/swrc/
Author: Katsutoshi Seki
License: GNU General Public License
Version of this distribution: 1.0 (JJSSP version) 
Please read manual.pdf for more information.
