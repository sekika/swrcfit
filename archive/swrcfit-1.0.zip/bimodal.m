#!/usr/bin/octave -qf
# SWRC Fit version 1.0 (JJSSP version)
# http://purl.org/net/swrc/

# Read data from file
output_precision=7;
load swrc.txt
[s, i] = sort (swrc (:, 1));
sorted = swrc (i, :);
x=sorted(:,1);
y=sorted(:,2);

# Setting
thetaSin = max(y); # initial value of thetaS
cts = 1; # set cts=1 when you fit thetaS, cts=0 when not
thetaRin = 0; # initial value of thetaR
ctr = 1; # set ctr=1 when you fit thetaR, ctr=0 when not

# Check if there are more than 7 points
if i < 8, disp("Too few points"), exit, end

# Bimodal model of Durner
disp ("=== DB model ===");

i = 3;
while (i < length(x)-1)
xi=x(1:i); yi=y(1:i);
thetaS=thetaSin; thetaR=min(yi);
S=(yi.-thetaR)./(thetaS-thetaR);
function ret=VG(x,p)
  ret = p(2)+(p(1)-p(2)).*((1+(abs(p(3)).*x).^(abs(p(4))+1)).^(1/(abs(p(4))+1)-1));
endfunction
hm = xi(sum (S > 0.5)+1);
alpha=1/hm; nn=1; pin=[1 0 alpha nn];
dp=[0 0 0.001 0.001]; stol=1; R2b=0;
wt=ones(length(yi),1);
while ( stol >= 0.0001 )
  [f,p,kvg]=leasqr(xi,S,pin,"VG",0.01,20,wt,dp);
  if kvg ==0, p=pin;, stol=0;, end
  stol=stol/10; pin=p;
endwhile
alpha1(i)=p(3); n1(i)=abs(p(4))+1;
y2=y.-(thetaS-thetaR).*(1+(alpha1(i).*x).^n1(i)).^(1./n1(i)-1);
hm = x(sum (S > 0.5)+1);
pin=[thetaR thetaRin 1/hm 1]; stol=1; 
wt=ones(length(y),1);
dp=[0 0.0001*ctr 0.0001 0.0001]; R2b=0;
while ( stol >= 0.0001 )
  [f,p,kvg,itr,corp,covp,cov,std,Z,R2]=leasqr(x,y2,pin,"VG",stol,20,wt,dp);
  if kvg == 0, p=pin;, R2=R2b;, stol=0;, end
  if imag(R2)^2>0, p=pin; R2=R2b;, stol=0;, end
  stol=stol/10; pin=p; R2b=R2;
endwhile
alpha2(i)=real(p(3)); n2(i)=abs(real(p(4)))+1;
tr(i)=real(p(2)); w1(i)=(thetaS-thetaR)/(thetaS-tr(i));
R(i)=real(R2);
i++;
endwhile

# Set initial condition
[Rmax, i]=max(R);
pin=[thetaSin tr(i) w1(i) 1/alpha1(i) n1(i) 1/alpha2(i) n2(i)];
wt=ones(length(y),1);

# Calculate
function ret=F(x,p)
  n1=mod(abs(p(5)),49)+1; n2=mod(abs(p(7)),49)+1; w1=mod(p(3),1);
  ret = p(2)+(p(1)-p(2)).*(w1.*(1+(x./abs(p(4))).^n1).^(1/n1-1) + (1-w1).*(1+(x./abs(p(6))).^n2).^(1/n2-1));
endfunction
stol=8; R2b=0;
dp=[0 0.001 0.001 0 0.01 0 0.01];
while ( stol >= 0.5 )
  [f,p,kvg,itr,corp,covp,covr,std,Z,R2]=leasqr(x,y,pin,"F",stol,20,wt,dp);
  if kvg == 0, p=pin;, R2=R2b;, stol=0;, end
  if imag(R2)^2>0, p=pin; R2=R2b;, stol=0;, end
  stol=stol/4; pin=p; R2b=R2;
endwhile
stol=1; R2b=0;
dp=[0.000001*cts 0.001*ctr 0.001 0.01 0.001 0.1 0.001];
while ( stol >= 0.00001 )
  [f,p,kvg,itr,corp,covp,covr,std,Z,R2]=leasqr(x,y,pin,"F",stol,20,wt,dp);
  if kvg == 0, p=pin;, R2=R2b;, stol=0;, end
  if imag(R2)^2>0, p=pin; R2=R2b;, stol=0;, end
  stol=stol/8; pin=p; R2b=R2;
endwhile
if abs(p(4)) > abs(p(6))
  p=[p(1) p(2) 1-p(3) p(6) p(7) p(4) p(5)];
end
w1 = mod(p(3),1);
if (w1 > 0.01) * (w1 < 0.99)
  thetaS = p(1)
  thetaR = p(2)
  w1
  alpha1 = 1/abs(p(4))
  n1 = mod(abs(p(5)),49)+1
  alpha2 = 1/abs(p(6))
  n2 = mod(abs(p(7)),49)+1
  R2
else
  disp ("Not bimodal");
end

