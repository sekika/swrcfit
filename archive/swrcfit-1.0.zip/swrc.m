#!/usr/bin/octave -qf
# SWRC Fit version 1.0 (JJSSP version)
# http://purl.org/net/swrc/

# Read data from file
output_precision=7;
load swrc.txt
[s, i] = sort (swrc (:, 1));
sorted = swrc (i, :);
x=sorted(:,1); y=sorted(:,2);

# Setting
thetaSin = max(y); # initial value of thetaS
cts=1; # cts=1; thetaS is variable, cts=0; thetaS is constant
thetaRin = min(y); # initial value of thetaR
ctr=1; # ctr=1; thetaS is variable, ctr=0; thetaS is constant

# Set initial values
thetaS=thetaSin; thetaR=thetaRin;
hbi = sum (y > max(y) * 0.95 + min(y) * 0.05)+1;
hb=x(hbi); hby=(y(hbi)-thetaR)/(thetaS-thetaR);
if hb==0, hb=x(2)/10;, end
hli = sum (y > max(y) * 0.15 + min(y) * 0.85);
if hbi==hli; hli=hli+1;, end
hl=x(hli); hly=(y(hli)-thetaR)/(thetaS-thetaR);
lambda=-log(hly/hby)/log(hl/hb);
if lambda < 0.1, lambda=0.1;, end
if lambda > 10, lambda=10;, end

# Brooks and Corey Model
disp ("=== BC model ===");
x2 = x .+ (x == 0) .* 0.001;
function ret=BC(x,p)
  ret = (x > p(3)) .* (p(2)+(p(1)-p(2)).*(x./p(3)).^(-p(4))) \
           + (x <= p(3)) .* p(1);
endfunction
pin=[thetaS, thetaR, hb, lambda];
stol=1; wt=ones(length(y),1);
dp=[0.00001*cts 0.001*ctr 0.1 0.01]; R2b=0;
while ( stol >= 0.00001 )
  [f,p,kvg,itr,corp,covp,covr,std,z,R2]=leasqr(x2,y,pin,"BC",stol,20,wt,dp);
  if kvg == 0, p=pin;, R2=R2b;, stol=0;, end
  stol=stol/10; pin=p; R2b=R2;
endwhile
thetaS=p(1), thetaR=p(2), hb=p(3), lambda=p(4), R2

# van Genuchten Model
disp ("=== VG model ===");
function ret=VG(x,p)
  n=abs(p(4))+1;
  ret = p(2)+(p(1)-p(2)).*(1+(abs(p(3)).*x).^n).^(1/n-1);
endfunction
thetaS=thetaSin; thetaR=thetaRin;
hm = x(sum(y > max(y)/2 + min(y)/2)+1);
alpha=1/hm; n=lambda+1;
if n < 1.1, n=1.1;, end
if n > 10, n=10;, end
pin=[thetaS, thetaR, alpha, n-1];
stol=1; dp=[0.00001*cts 0.001*ctr 0.1 0.001]; R2b=0;
while ( stol >= 0.00001 )
  [f,p,kvg,itr,corp,covp,covr,std,Z,R2]=leasqr(x,y,pin,"VG",stol,20,wt,dp);
  if kvg == 0, p=pin;, R2=R2b;, stol=0;, end
  if imag(R2)^2>0, p=pin; R2=R2b;, stol=0;, end
  stol=stol/10; pin=p; R2b=R2;
endwhile
thetaS=p(1), thetaR=p(2), alpha=abs(p(3)), n=abs(p(4))+1, R2

# Lognormal Pore-Size Distribution Model of Kosugi
disp ("=== LN model ===");
function ret=LN(x,p)
  ret = p(2)+(p(1)-p(2)).*(1-normcdf((log(x/abs(p(3))))./abs(p(4))));
endfunction
thetaS=thetaSin; thetaR=thetaRin; hm=1/alpha;
sigma=1.2*(n-1)^(-0.8);
if sigma < 0.15, sigma=0.15;, end
if sigma > 3, sigma=3;, end
pin=[thetaS, thetaR, hm, sigma];
stol=1; dp=[0.00001*cts 0.0001*ctr 0.01 0.01]; R2b=0;
while ( stol >= 0.00001 )
  [f,p,kvg,itr,corp,covp,covr,std,Z,R2]=leasqr(x,y,pin,"LN",stol,20,wt,dp);
  if kvg == 0, p=pin;, R2=R2b;, stol=0;, end
  if imag(R2)^2>0, p=pin; R2=R2b;, stol=0;, end
  stol=stol/10; pin=p; R2b=R2;
endwhile
thetaS=p(1), thetaR=p(2), hm=abs(p(3)), sigma=abs(p(4)), R2

