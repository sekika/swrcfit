# swrcfit (SWRC Fit) - Fitting soil water retention curve

Choose language.

- [English](doc/en/README.md)
- [日本語](doc/ja/README.md)

This file is written in markdown language and online version is better
for browzing. User's manual of SWRC fit for each version is available
here: https://github.com/sekika/swrcfit/wiki/User%27s-manual
